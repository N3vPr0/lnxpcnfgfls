# chezmoi Plugin

## Introduction

This `chezmoi` plugin sets up completion for [chezmoi](https://chezmoi.io).

To use it, add `chezmoi` to the plugins array of your zshrc file:

```bash
plugins=(... chezmoi)
```
